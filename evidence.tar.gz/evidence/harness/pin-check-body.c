/* Calls the exact helper extracted from the candidate source. */
int main(void) {
  CUDA_CHECK(cudaSetDevice(0));
  assert(register_host_matrix(NULL, 0) == 0);
  void *buffer = NULL;
  assert(posix_memalign(&buffer, 4096, 16384) == 0);
  memset(buffer, 1, 16384);
  for (int i = 0; i < 3; ++i) {
    assert(register_host_matrix(buffer, 8192) == 1);
    assert(register_host_matrix(buffer, 8192) == 0);
    CUDA_CHECK(cudaHostUnregister(buffer));
  }
  CUDA_CHECK(cudaHostRegister(buffer, 8192, cudaHostRegisterDefault));
  assert(register_host_matrix(buffer, 8192) == 0);
  CUDA_CHECK(cudaHostUnregister(buffer));
  /* Distinct allocations can share pages; an overlapping registration must
   * not cause us to remove the first owner's registration. */
  assert(register_host_matrix(buffer, 4096) == 1);
  int owns_overlap = register_host_matrix((char *)buffer + 2048, 4096);
  printf("OVERLAP_OWNED %d\n", owns_overlap);
  void *device = NULL;
  cudaStream_t stream;
  CUDA_CHECK(cudaMalloc(&device, 4096));
  CUDA_CHECK(cudaStreamCreate(&stream));
  CUDA_CHECK(cudaMemcpyAsync(device, (char *)buffer + 2048, 4096,
                            cudaMemcpyHostToDevice, stream));
  CUDA_CHECK(cudaMemcpyAsync((char *)buffer + 2048, device, 4096,
                            cudaMemcpyDeviceToHost, stream));
  CUDA_CHECK(cudaStreamSynchronize(stream));
  for (int i = 2048; i < 6144; ++i) assert(((char *)buffer)[i] == 1);
  CUDA_CHECK(cudaFree(device));
  CUDA_CHECK(cudaStreamDestroy(stream));
  if (owns_overlap) CUDA_CHECK(cudaHostUnregister((char *)buffer + 2048));
  CUDA_CHECK(cudaHostUnregister(buffer));
  free(buffer);
  puts("HOST_REGISTRATION_PASS zero_size repeated pre_registered overlapping_pages");
  return 0;
}
