"""Read this Slurm job's cgroup memory use, without changing resource limits."""
import csv
from datetime import datetime, timezone
import os
from pathlib import Path
import time

groups=Path("/proc/self/cgroup").read_text().splitlines()
relative=next((line.split(":",2)[2] for line in groups if line.startswith("0::")), None)
if relative is None:
    raise SystemExit("Unified cgroup memory statistics unavailable")
group=Path("/sys/fs/cgroup") / relative.lstrip("/")
job=os.environ["SLURM_JOB_ID"]
for parent in (group, *group.parents):
    if parent.name in ("job_"+job, "job-"+job+".scope"):
        group=parent
        break
writer=csv.writer(__import__("sys").stdout)
writer.writerow(["utc", "cgroup", "current_bytes", "peak_bytes", "limit_bytes"])
while True:
    values=[]
    for name in ("memory.current", "memory.peak", "memory.max"):
        p=group/name
        values.append(p.read_text().strip() if p.exists() else "")
    writer.writerow([datetime.now(timezone.utc).isoformat(), str(group), *values])
    __import__("sys").stdout.flush()
    time.sleep(2)
