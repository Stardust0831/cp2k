"""Use the accepted image and immutable dependency/build mounts."""
import json
import os
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
request = json.loads((root / "request.json").read_text())
args = ["apptainer", "exec", "--nv", "--cleanenv", "--no-home", "--no-mount",
        "bind-paths,home,cwd,tmp,hostfs"]
for path in ("/usr", "/lib", "/lib64", "/etc", "/opt/devtools", "/opt/modules",
             request["baseline_campaign"], request["reused_campaign"]):
    args += ["--bind", path + ":" + path + ":ro"]
args += ["--bind", "/opt/devtools/nvidia/hpc_sdk/Linux_x86_64/26.3/comm_libs/12.9/hpcx/hpcx-2.25.1/hcoll:/opt/mellanox/hcoll:ro"]
args += ["--bind", str(root) + ":" + str(root) + ":rw",
         "--bind", request["dependency_directory"] + ":" + request["dependency_prefix"] + "/dependencies:ro",
         "--bind", "/var/tmp:/var/tmp:rw", "--pwd", str(Path.cwd())]
for key, value in os.environ.items():
    if key.startswith(("SLURM_", "OMPI_", "OPAL_", "PMIX_", "PMI_", "PRTE_", "UCX_", "NCCL_", "CUDA_", "FI_", "OMP_", "PIKA_", "DLAF_", "SAI_TRANSFER_")) or key in ("TMPDIR", "OPENBLAS_NUM_THREADS"):
        args += ["--env", key + "=" + value]
args += [request["image"], "/usr/bin/bash", "--noprofile", "--norc",
         str(root / "inside-v2.sh"), *sys.argv[1:]]
os.execvp(args[0], args)
