/* Test-only interposer: count the Q copies in ELPA's band-to-full routine. */
#define _GNU_SOURCE
#include <cuda_runtime.h>
#include <dlfcn.h>
#include <execinfo.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static _Thread_local void *q_host;
static _Thread_local size_t full_bytes, upload_bytes, download_bytes;
static int band_to_full(void) {
  void *frames[20];
  int n = backtrace(frames, 20);
  for (int i = 0; i < n; ++i) {
    Dl_info info;
    if (dladdr(frames[i], &info) && info.dli_sname &&
        strstr(info.dli_sname, "trans_ev_band_to_full")) return 1;
  }
  return 0;
}
cudaError_t cudaHostRegister(void *ptr, size_t bytes, unsigned int flags) {
  typedef cudaError_t (*fn)(void *, size_t, unsigned int);
  fn original = (fn)dlsym(RTLD_NEXT, "cudaHostRegister");
  cudaError_t error = original(ptr, bytes, flags);
  if (!q_host && band_to_full() && error == cudaSuccess) {
    q_host = ptr;
    full_bytes = bytes;
    upload_bytes = download_bytes = 0;
  }
  return error;
}
cudaError_t cudaMemcpyAsync(void *dst, const void *src, size_t bytes,
                            enum cudaMemcpyKind kind, cudaStream_t stream) {
  typedef cudaError_t (*fn)(void *, const void *, size_t, enum cudaMemcpyKind,
                            cudaStream_t);
  fn original = (fn)dlsym(RTLD_NEXT, "cudaMemcpyAsync");
  cudaError_t error = original(dst, src, bytes, kind, stream);
  if (q_host && error == cudaSuccess) {
    if (kind == cudaMemcpyHostToDevice && src == q_host) upload_bytes += bytes;
    if (kind == cudaMemcpyDeviceToHost && dst == q_host) download_bytes += bytes;
  }
  return error;
}
cudaError_t cudaHostUnregister(void *ptr) {
  typedef cudaError_t (*fn)(void *);
  fn original = (fn)dlsym(RTLD_NEXT, "cudaHostUnregister");
  cudaError_t error = original(ptr);
  if (ptr == q_host) {
    fprintf(stderr, "Q_TRANSFER rank=%s full=%zu upload=%zu download=%zu unregister=%d\n",
            getenv("OMPI_COMM_WORLD_RANK"), full_bytes, upload_bytes,
            download_bytes, (int)error);
    q_host = NULL;
  }
  return error;
}
