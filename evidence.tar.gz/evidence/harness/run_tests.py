"""Focused numerical acceptance followed by three paired ENERGY_FORCE repeats."""
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import tomllib

root = Path(__file__).resolve().parent
results = root / "results"
q = json.loads((root / "request.json").read_text())
old = Path(q["baseline_campaign"])
plan = json.loads((root / "benchmark-plan.json").read_text())
mpi = ["mpirun", "-np", "4", "--map-by", "ppr:4:node:pe=4", "--bind-to", "core", "--report-bindings"]
container = ["python3", str(root / "container.py")]
sys.path.insert(0, str(old / "source/tests"))
from matchers import run_matcher

def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

def run(name, command, cwd=root, timeout=600, variant="cu-base", mode="run"):
    receipt = dict(command=[str(v) for v in command], cwd=str(cwd), variant=variant, mode=mode,
                   job=os.environ["SLURM_JOB_ID"], started_at=datetime.now(timezone.utc).isoformat())
    (results / "current-stage.json").write_text(json.dumps(dict(stage=name, **receipt),indent=2)+"\n")
    print("START",name,flush=True)
    start=time.monotonic()
    env=dict(os.environ,SAI_TRANSFER_VARIANT=variant,SAI_TRANSFER_MODE=mode)
    if (results/(name+"-receipt.json")).exists():
        prior=json.loads((results/(name+"-receipt.json")).read_text())
        assert prior["exit_code"] != 0, "Do not repeat an already successful stage"
        (results/(name+".log")).rename(results/(name+"-missing-relative-fixture.log"))
        (results/(name+"-receipt.json")).rename(results/(name+"-missing-relative-fixture-receipt.json"))
    with (results/(name+".log")).open("w") as log:
        process=subprocess.Popen(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            receipt["exit_code"]=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            receipt.update(exit_code=124,timed_out=True)
            os.killpg(process.pid,signal.SIGTERM)
            try:
                process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                process.wait(timeout=20)
    receipt.update(seconds=time.monotonic()-start,finished_at=datetime.now(timezone.utc).isoformat())
    (results/(name+"-receipt.json")).write_text(json.dumps(receipt,indent=2)+"\n")
    print("END",name,receipt["exit_code"],round(receipt["seconds"],3),flush=True)
    assert receipt["exit_code"]==0,(name,receipt)
    return (results/(name+".log")).read_text(errors="replace")

assert (results/"build-completed.json").is_file()
assert digest(q["image"])==q["image_sha256"]
for p,expected in json.loads((root/"fixtures.json").read_text())["files"].items():
    assert digest(root/p)==expected,p
for name,command in (("test-allocation",["scontrol","show","job","-o",os.environ["SLURM_JOB_ID"]]),
                     ("test-lscpu",["lscpu"]), ("gpu-topology",["nvidia-smi","topo","-m"]),
                     ("gpu-identity",["nvidia-smi","--query-gpu=index,uuid,name,memory.total,driver_version","--format=csv"])):
    run(name,command)

runtime={}
for variant in q["variants"]:
    cpvariant="cu-pinned" if variant=="cu-pinned" else "cu-base"
    elpavariant="elpa-q" if variant=="elpa-q" else "elpa-base"
    library=root/"cp2k"/cpvariant/"libcp2k.so.2026.2"
    elpa=(root/"elpa"/elpavariant/"lib/libelpa_openmp.so").resolve()
    text=run(variant+"-ldd",container+["inspect","ldd",str(root/"bin/cp2k.psmp")],variant=variant)
    assert str(library) in text and str(elpa.parent/"libelpa_openmp.so.19") in text and "not found" not in text
    version=run(variant+"-version",container+["inspect",str(root/"bin/cp2k.psmp"),"--version"],variant=variant)
    assert q["source_base"] in version and "cusolvermp" in version.lower() and "dlaf" in version.lower()
    runtime[variant]=dict(cp2k_sha256=digest(library),elpa_sha256=digest(elpa),cp2k_library=str(library),elpa_library=str(elpa))
(results/"runtime.json").write_text(json.dumps(runtime,indent=2)+"\n")

run("lifecycle-build",container+["build","mpicc","-O2","-std=c11","-Wall","-Wextra","-Werror",
    "-I"+str(old/"source/src/start"),"-L"+str(root/"cp2k/cu-base"),"-Wl,-rpath,"+str(root/"cp2k/cu-base"),
    str(root/"lifecycle.c"),"-lcp2k","-lm","-o",str(root/"bin/lifecycle")])
run("elpa-check-build",container+["build","mpicc","-O2","-std=c11","-Wall","-Wextra","-Werror",
    "-I"+str(root/"elpa/elpa-base/include"),"-L"+str(root/"elpa/elpa-base/lib"),
    "-Wl,-rpath,"+str(root/"elpa/elpa-base/lib"),str(root/"elpa-check.c"),"-lelpa_openmp","-lm","-o",str(root/"bin/elpa-check")])

source=(root/"source/src/fm/cp_fm_cusolver.c").read_text()
macro=source[source.index("#define CUDA_CHECK(cmd)"):source.index("\n#if defined(__CUSOLVERMP_NCCL)",source.index("#define CUDA_CHECK(cmd)"))]
helper=re.search(r"static int register_host_matrix\(.*?\n\}",source,re.S)[0]
(root/"pin-check.c").write_text('#define _POSIX_C_SOURCE 200809L\n#include <assert.h>\n#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <cuda_runtime.h>\n'+macro+'\n'+helper+'\n'+(root/"pin-check-body.c").read_text())
cuda="/opt/devtools/nvidia/cuda-12.9.1"
run("pin-check-build",container+["build","gcc","-O2","-std=c11","-Wall","-Wextra","-Werror",
    "-I"+cuda+"/include",str(root/"pin-check.c"),"-L"+cuda+"/lib64","-Wl,-rpath,"+cuda+"/lib64","-lcudart","-o",str(root/"bin/pin-check")])
work=results/"pin-check"
work.mkdir()
text=run("pin-check",mpi+["python3",str(root/"rank.py")],cwd=work,mode="pin-check",variant="cu-pinned")
assert text.count("HOST_REGISTRATION_PASS")==4

lifecycles={}
for variant in ("cu-base","cu-pinned"):
    work=results/(variant+"-lifecycle")
    work.mkdir()
    for path in (root/"validation-inputs").iterdir():
        if path.is_file():shutil.copy2(path,work/path.name)
    text=run(variant+"-lifecycle",mpi+["python3",str(root/"rank.py")],cwd=work,mode="lifecycle",variant=variant)
    assert "CP2K_CUSOLVER_LIFECYCLE_COMPLETE" in text
    records={}
    for file in work.glob("observables-g*.jsonl"):
        for line in file.read_text().splitlines():
            row=json.loads(line)
            key=f"{row['phase']}/{row['case']}/{row['group']}/{row['step']}"
            assert key not in records and len(row["forces"])==24
            assert all(math.isfinite(v) for v in [row["energy_ha"],*row["forces"]])
            records[key]=row
    assert len(records)==18,(variant,len(records))
    for out in work.glob("*.out"):
        assert "diagonalization failed" not in out.read_text(errors="replace"),out
    lifecycles[variant]=records
base=lifecycles["cu-base"]
assert base.keys()==lifecycles["cu-pinned"].keys()
delta={}
for key,candidate in lifecycles["cu-pinned"].items():
    de=abs(candidate["energy_ha"]-base[key]["energy_ha"])
    df=max(abs(a-b) for a,b in zip(candidate["forces"],base[key]["forces"]))
    assert de<=1e-8 and df<=1e-7,(key,de,df)
    delta[key]=dict(energy_delta_ha=de,max_force_component_delta_ha_bohr=df)
(results/"lifecycle-audit.json").write_text(json.dumps(dict(accepted=True,comparisons=delta,observables=lifecycles),indent=2)+"\n")

elpa_checks=[]
for variant in ("elpa-base","elpa-q"):
    for nev in (16,95,193):
        for complex_case in (0,1):
            for nonblocking in (0,1):
                name=f"{variant}-nev{nev}-complex{complex_case}-nbc{nonblocking}"
                work=results/name
                work.mkdir()
                text=run(name,mpi+["python3",str(root/"rank.py"),str(nev),str(complex_case),str(nonblocking)],cwd=work,mode="elpa-check",variant=variant,timeout=180)
                assert text.count("ELPA_NUMERIC PASS")==2
                elpa_checks.append(dict(name=name,passed=True,summary=[s for s in text.splitlines() if s.startswith("ELPA_NUMERIC")]))
                (results/"elpa-checks.json").write_text(json.dumps(elpa_checks,indent=2)+"\n")

# Preserve upstream relative coordinate/data references in the copied suites.
for sample in (old/"source/tests/QS").iterdir():
    if sample.is_dir() and sample.name.startswith("sample_"):
        target=results/sample.name
        if not target.exists(): target.symlink_to(sample,target_is_directory=True)
regtests=json.loads((results/"regtests.json").read_text()) if (results/"regtests.json").exists() else []
completed_names={row["name"] for row in regtests if row["passed"]}
for variant,dirs in (("cu-base",["regtest-cusolver"]),("cu-pinned",["regtest-cusolver"]),
                     ("elpa-base",["regtest-elpa","regtest-elpa-2"]),("elpa-q",["regtest-elpa","regtest-elpa-2"])):
    for directory in dirs:
        source=old/"source/tests/QS"/directory
        specs=tomllib.loads((source/"TEST_FILES.toml").read_text())
        # Several upstream tests share files within the directory.
        work=results/(variant+"-"+directory)
        shutil.copytree(source,work,dirs_exist_ok=True)
        for filename,matchers in specs.items():
            name=variant+"-"+directory+"-"+filename.removesuffix(".inp")
            if name in completed_names: continue
            output=run(name,mpi+["python3",str(root/"rank.py"),"-i",filename],cwd=work,variant=variant,timeout=300)
            (work/(filename+".out")).write_text(output)
            matches=[asdict(run_matcher(output,**spec)) for spec in matchers]
            row=dict(name=name,matchers=matches,passed="PROGRAM ENDED" in output and all(m["status"]=="OK" for m in matches))
            regtests.append(row)
            (results/"regtests.json").write_text(json.dumps(regtests,indent=2)+"\n")
            assert row["passed"],row

(results/"functional-completed.json").write_text(json.dumps(dict(job=os.environ["SLURM_JOB_ID"],finished_at=datetime.now(timezone.utc).isoformat()),indent=2)+"\n")
for case in plan:
    name=case["name"]
    work=results/name
    shutil.copytree(root/case["input"],work)
    assert not any(".wfn" in p.name.lower() for p in work.iterdir())
    text=run(name,mpi+["python3",str(root/"rank.py"),"-i","input.inp"],cwd=work,variant=case["variant"],timeout=case["timeout"])
    (work/"cp2k.out").write_text(text)
    subprocess.run(["python3",str(root/"audit_benchmark.py"),"--partial"],check=True)
subprocess.run(["python3",str(root/"audit_benchmark.py")],check=True)
(results/"benchmark-completed.json").write_text(json.dumps(dict(job=os.environ["SLURM_JOB_ID"],finished_at=datetime.now(timezone.utc).isoformat()),indent=2)+"\n")
print("TRANSFER_E2E_COMPLETE",flush=True)
