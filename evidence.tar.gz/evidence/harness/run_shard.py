"""Six paired converged calculations in one allocation for one backend/system."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

r=Path(__file__).resolve().parent
group=sys.argv[1]
q=json.loads((r/"request-v2.json").read_text())
plan=[p for p in json.loads((r/"benchmark-plan.json").read_text()) if p["family"]+"-"+p["backend"]==group]
assert len(plan)==6
out=r/"results/benchmarks"
out.mkdir(exist_ok=True)
assert (r/"results/functional-v2-completed.json").is_file()
mpi=["mpirun","-np","4","--map-by","ppr:4:node:pe=4","--bind-to","core","--report-bindings"]
container=["python3",str(r/"container-v2.py")]
digest=lambda p:hashlib.file_digest(Path(p).open("rb"),"sha256").hexdigest()
for p,expected in json.loads((r/"fixtures.json").read_text())["files"].items():assert digest(r/p)==expected,p

def run(name,command,cwd=r,variant="cu-base",timeout=1200):
    record=dict(command=command,cwd=str(cwd),variant=variant,group=group,job=os.environ["SLURM_JOB_ID"],started_at=datetime.now(timezone.utc).isoformat())
    (out/(group+"-current.json")).write_text(json.dumps(dict(stage=name,**record),indent=2)+"\n")
    print("START",name,flush=True)
    start=time.monotonic()
    with (out/(name+".log")).open("w") as f:
        process=subprocess.Popen(command,cwd=cwd,env=dict(os.environ,SAI_TRANSFER_VARIANT=variant,SAI_TRANSFER_MODE="run"),stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        try: record["exit_code"]=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            record.update(exit_code=124,timed_out=True)
            os.killpg(process.pid,signal.SIGTERM)
            try:process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                process.wait(timeout=20)
    record.update(seconds=time.monotonic()-start,finished_at=datetime.now(timezone.utc).isoformat())
    (out/(name+"-receipt.json")).write_text(json.dumps(record,indent=2)+"\n")
    print("END",name,record["exit_code"],round(record["seconds"],2),flush=True)
    assert record["exit_code"]==0,name
    return (out/(name+".log")).read_text(errors="replace")

run(group+"-allocation",["scontrol","show","job","-o",os.environ["SLURM_JOB_ID"]])
run(group+"-topology",["nvidia-smi","topo","-m"])
runtime={}
for variant in sorted({p["variant"] for p in plan}):
    cpvariant="cu-pinned-v2" if variant=="cu-pinned" else "cu-base"
    elpavariant="elpa-q" if variant=="elpa-q" else "elpa-base"
    cp=r/"cp2k"/cpvariant/"libcp2k.so.2026.2"
    elpa=r/"elpa"/elpavariant/"lib/libelpa_openmp.so.19"
    text=run(group+"-"+variant+"-ldd",container+["inspect","ldd",str(r/"bin/cp2k.psmp")],variant=variant)
    assert str(cp) in text and str(elpa) in text and "not found" not in text
    runtime[variant]=dict(cp2k=str(cp),cp2k_sha256=digest(cp),elpa=str(elpa),elpa_sha256=digest(elpa))
(out/(group+"-runtime.json")).write_text(json.dumps(runtime,indent=2)+"\n")
for case in plan:
    name=case["name"]
    work=out/name
    shutil.copytree(r/case["input"],work)
    assert not any(".wfn" in p.name.lower() for p in work.iterdir())
    text=run(name,mpi+["python3",str(r/"rank-v2.py"),"-i","input.inp"],cwd=work,variant=case["variant"],timeout=case["timeout"])
    (work/"cp2k.out").write_text(text)
    subprocess.run(["python3",str(r/"audit_shards.py"),"--partial","--group",group],check=True)
subprocess.run(["python3",str(r/"audit_shards.py"),"--group",group],check=True)
(out/(group+"-completed.json")).write_text(json.dumps(dict(group=group,job=os.environ["SLURM_JOB_ID"],finished_at=datetime.now(timezone.utc).isoformat()),indent=2)+"\n")
print("SHARD_COMPLETE",group,flush=True)
