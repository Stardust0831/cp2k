/* Exercise the exact candidate helper and real CUDA transfers after rollback. */
static void check_copy(void *host, size_t size, cudaStream_t stream) {
  void *device = NULL;
  memset(host, 37, size);
  CUDA_CHECK(cudaMalloc(&device, size));
  CUDA_CHECK(cudaMemcpyAsync(device, host, size, cudaMemcpyHostToDevice, stream));
  CUDA_CHECK(cudaStreamSynchronize(stream));
  memset(host, 0, size);
  CUDA_CHECK(cudaMemcpyAsync(host, device, size, cudaMemcpyDeviceToHost, stream));
  CUDA_CHECK(cudaStreamSynchronize(stream));
  for (size_t i = 0; i < size; ++i) assert(((char *)host)[i] == 37);
  CUDA_CHECK(cudaFree(device));
}
int main(void) {
  CUDA_CHECK(cudaSetDevice(0));
  cudaStream_t stream;
  CUDA_CHECK(cudaStreamCreate(&stream));
  void *buffer = NULL;
  assert(posix_memalign(&buffer, 4096, 24576) == 0);
  const void *matrices[] = {buffer, (char *)buffer + 8192, (char *)buffer + 16384};
  size_t sizes[] = {4096, 4096, 4096};
  for (int repeat = 0; repeat < 3; ++repeat) {
    assert(register_host_matrices(matrices, sizes, 3));
    for (int i = 0; i < 3; ++i) check_copy((void *)matrices[i], sizes[i], stream);
    unregister_host_matrices(matrices, sizes, 3);
  }
  /* A pre-registered buffer remains registered after preceding registrations
   * from this solve are rolled back. */
  CUDA_CHECK(cudaHostRegister((void *)matrices[1], sizes[1], cudaHostRegisterDefault));
  assert(!register_host_matrices(matrices, sizes, 3));
  for (int i = 0; i < 3; ++i) check_copy((void *)matrices[i], sizes[i], stream);
  CUDA_CHECK(cudaHostUnregister((void *)matrices[1]));
  /* Partly overlapping ranges must both become pageable before copying. */
  matrices[1] = (char *)buffer + 2048;
  assert(!register_host_matrices(matrices, sizes, 3));
  for (int i = 0; i < 3; ++i) check_copy((void *)matrices[i], sizes[i], stream);
  /* Aliased input/output and ranks with no requested local eigenvectors. */
  matrices[1] = matrices[0];
  sizes[2] = 0;
  assert(!register_host_matrices(matrices, sizes, 3));
  check_copy(buffer, sizes[0], stream);
  matrices[1] = (char *)buffer + 8192;
  matrices[2] = NULL;
  assert(register_host_matrices(matrices, sizes, 3));
  unregister_host_matrices(matrices, sizes, 3);
  CUDA_CHECK(cudaStreamDestroy(stream));
  free(buffer);
  puts("HOST_GROUP_PASS repeats pre_registered partial_overlap alias zero_local_columns copies");
  return 0;
}
