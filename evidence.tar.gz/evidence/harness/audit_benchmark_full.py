"""Verify matched runs before deriving any within-campaign timing ratios."""
import argparse
import json
import math
from pathlib import Path
import re
import statistics

parser = argparse.ArgumentParser()
parser.add_argument("--partial", action="store_true")
args = parser.parse_args()
root = Path(__file__).resolve().parent
results = root / "results"
request = json.loads((root / "request.json").read_text())
request["cases"] = json.loads((root / "benchmark-plan.json").read_text())
number = r"[-+]?\d+(?:\.\d*)?(?:[EeDd][-+]?\d+)?"
errors = []


def check(ok, message):
    if not ok:
        errors.append(message)


def num(value):
    result = float(value.replace("D", "E").replace("d", "e"))
    assert math.isfinite(result), value
    return result


def timers(text):
    chunks = re.split(r"T I M I N G", text)
    assert len(chunks) == 2, "Expected one final timing table"
    answer = {}
    for line in chunks[-1].splitlines():
        fields = line.split()
        if len(fields) not in (7, 8) or not re.fullmatch(r"\w+", fields[0]):
            continue
        try:
            row = dict(calls=int(fields[1]), depth=num(fields[2]),
                       self_average_seconds=num(fields[3]), self_max_seconds=num(fields[4]),
                       total_average_seconds=num(fields[5]), total_max_seconds=num(fields[6]))
        except (ValueError, AssertionError):
            continue
        assert fields[0] not in answer, fields[0]
        answer[fields[0]] = row
    return answer


cases = {}
reference_mapping = None
for spec in request["cases"]:
    name = spec["name"]
    receipt_path = results / (name + "-receipt.json")
    if not receipt_path.exists() and args.partial:
        continue
    if receipt_path.exists() and spec.get("pilot") and json.loads(receipt_path.read_text())["exit_code"]:
        continue
    path = results / name
    for original in (root / spec["input"]).iterdir():
        if original.is_file():
            check((path / original.name).read_bytes() == original.read_bytes(), name + " fixture " + original.name)
    text = (path / "cp2k.out").read_text(errors="replace")
    receipt = json.loads(receipt_path.read_text())
    check(receipt["exit_code"] == 0, name + " process exit")
    check("PROGRAM ENDED" in text, name + " normal completion")
    energy = re.findall(r"ENERGY\| Total FORCE_EVAL[^\n]*?(" + number + r")\s*$", text, re.M)
    force_rows = re.findall(r"^\s*FORCES\|\s+(\d+)\s+(" + number + r")\s+(" + number +
                            r")\s+(" + number + r")\s+" + number + r"\s*$", text, re.M)
    check(len(energy) == 1, name + " one energy")
    check([int(row[0]) for row in force_rows] == list(range(1, spec["atoms"] + 1)), name + " complete ordered atom forces")
    steps = [int(x) for x in re.findall(r"SCF run converged in\s+(\d+) steps", text)]
    check(steps == [spec["expected_scf_steps"]], name + " SCF steps " + repr(steps))
    check(re.search(r"DBCSR\| ACC: GPU backend is enabled\s+T", text) is not None, name + " DBCSR GPU enabled")
    acc = re.findall(r"^\s*flops total\s+\S+\s+\S+%\s+\S+%\s+([\d.]+)%", text, re.M)
    acc_percent = float(acc[0]) if len(acc)==1 else None
    measured = timers(text)
    stage, backend = (("eigensolver_dbcsr", "cp_fm_diag_elpa") if spec["backend"] == "elpa"
                      else ("eigensolver_generalized", "cp_fm_general_cusolver" if spec["backend"]=="cusolver" else "cp_fm_diag_gen_dlaf"))
    check(measured.get("CP2K", {}).get("calls") == 1, name + " CP2K total timer")
    for timer in (stage, backend):
        check(measured.get(timer, {}).get("calls") == spec["expected_scf_steps"], name + " backend/stage timer " + timer)
    if spec["backend"] == "elpa":
        blocks = [int(x) for x in re.findall(r"ELPA\| Matrix block size \(NBLK\)\s+(\d+)", text)]
        kernels = re.findall(r"ELPA\| Kernel\s+(\S+)", text)
        check(bool(blocks) and set(blocks) == {64}, name + " default ELPA block 64")
        check(bool(kernels) and set(kernels) == {"NVIDIA_GPU"}, name + " ELPA GPU kernel")
        check(acc_percent is not None and acc_percent > 0, name + " DBCSR GPU multiplication executed")
    mappings = [json.loads(p.read_text()) for p in sorted(path.glob("rank-*.json"))]
    check(len(mappings) == 4 and {r["rank"] for r in mappings} == set(range(4)), name + " four ranks")
    check(len({r["host"] for r in mappings}) == 1 and len({r["gpu"] for r in mappings}) == 4, name + " four distinct GPUs")
    check(all(len(r["cores"]) == 4 for r in mappings), name + " four cores per rank")
    check(len({tuple(c) for r in mappings for c in r["cores"]}) == 16, name + " 16 nonoverlapping physical cores")
    actual_mapping = [{k:r[k] for k in ("rank", "host", "gpu", "cores", "job")} for r in mappings]
    if reference_mapping is None:
        reference_mapping = actual_mapping
    check(actual_mapping == reference_mapping, name + " unchanged rank/GPU/core mapping")
    cases[name] = dict(**spec, energy_ha=num(energy[0]) if len(energy) == 1 else None,
                       forces=[num(value) for row in force_rows for value in row[1:]],
                       scf_steps=steps, timers=measured, stage_timer=stage, backend_timer=backend,
                       process_wall_seconds=receipt["seconds"], mapping=actual_mapping, dbcsr_acc_percent=acc_percent)

for family in ("ag", "diamond"):
    subset = [r for r in cases.values() if r["family"] == family]
    if not subset:
        continue
    reference = cases[family + "-cu-base-r1"]
    for case in subset:
        name = case["name"]
        if case["energy_ha"] is not None and reference["energy_ha"] is not None:
            case["energy_delta_ha"] = abs(case["energy_ha"] - reference["energy_ha"])
            check(case["energy_delta_ha"] <= request["energy_tolerance_ha"], name + " energy tolerance")
        if len(case["forces"]) == len(reference["forces"]) and case["forces"]:
            case["max_force_component_delta_ha_bohr"] = max(abs(a-b) for a,b in zip(case["forces"], reference["forces"]))
            check(case["max_force_component_delta_ha_bohr"] <= request["force_tolerance_ha_bohr"], name + " force tolerance")

complete = all((results / (spec["name"] + "-receipt.json")).exists() for spec in request["cases"])
statistics_by_family = {}
if complete and not errors:
    for family in ("ag", "diamond"):
        summary = {}
        for variant in ("cu-base", "cu-pinned", "elpa-base", "elpa-q"):
            if not any(r["family"]==family and r["variant"]==variant for r in cases.values()):
                continue
            rows = sorted((r for r in cases.values() if r["family"] == family and r["variant"] == variant), key=lambda r:r["repetition"])
            summary[variant] = {}
            for metric in ("cp2k", "stage", "backend", "process_wall"):
                values = [r["process_wall_seconds"] if metric == "process_wall" else
                          r["timers"]["CP2K" if metric == "cp2k" else r[metric + "_timer"]]["total_max_seconds"] for r in rows]
                summary[variant][metric] = dict(values=values, median=statistics.median(values), minimum=min(values), maximum=max(values))
        summary["speedup"] = {backend:{metric:summary[base][metric]["median"]/summary[candidate][metric]["median"]
                              for metric in ("cp2k", "stage", "backend", "process_wall")}
                              for backend,base,candidate in (("cu_pinning","cu-base","cu-pinned"),("elpa_q","elpa-base","elpa-q"))}
        statistics_by_family[family] = summary
report = dict(accepted=not errors and complete, partial=args.partial, complete=complete, errors=errors,
              cases=cases, statistics=statistics_by_family,
              timer_semantics="Primary CP2K and stage comparisons use TOTAL MAX. Speedups compare medians of three paired runs. Inputs, process mapping and all unaffected objects/dependencies are identical. Full ENERGY_FORCE convergence and all force components are checked.")
(results / "audit-result.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(dict(complete=complete, cases=len(cases), errors=errors, statistics=statistics_by_family), indent=2))
raise SystemExit(bool(errors) or (not args.partial and not complete))
