"""Rebuild only the corrected CP2K wrapper and repeat affected acceptance tests."""
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import tomllib

r=Path(__file__).resolve().parent
q=json.loads((r/"request-v2.json").read_text())
old=Path(q["baseline_campaign"])
out=r/"results/v2-functional"
out.mkdir(exist_ok=False)
container=["python3",str(r/"container-v2.py")]
mpi=["mpirun","-np","4","--map-by","ppr:4:node:pe=4","--bind-to","core","--report-bindings"]
os.environ["SAI_TRANSFER_VARIANT"]="cu-pinned"
sys.path.insert(0,str(old/"source/tests"))
from matchers import run_matcher

def run(name,args,cwd=r,mode="run",variant="cu-pinned"):
    start=time.monotonic()
    print("START",name,flush=True)
    with (out/(name+".log")).open("w") as log:
        p=subprocess.run(args,cwd=cwd,env=dict(os.environ,SAI_TRANSFER_MODE=mode,SAI_TRANSFER_VARIANT=variant),stdout=log,stderr=subprocess.STDOUT)
    (out/(name+"-receipt.json")).write_text(json.dumps(dict(exit_code=p.returncode,seconds=time.monotonic()-start,job=os.environ["SLURM_JOB_ID"],command=args,cwd=str(cwd),variant=variant),indent=2)+"\n")
    assert p.returncode==0,name
    print("END",name,round(time.monotonic()-start,2),flush=True)
    return (out/(name+".log")).read_text(errors="replace")

source=r/"source-v2/src/fm"
source.mkdir(parents=True)
shutil.copy2(old/"source/src/fm/cp_fm_cusolver.c",source/"cp_fm_cusolver.c")
(source.parent/"offload").symlink_to(old/"source/src/offload",target_is_directory=True)
run("patch",["patch","--batch","--fuzz=0","-p1","-d",str(r/"source-v2"),"-i",str(r/"cusolver-host-pinning-v2.patch")])
run("rebuild",container+["build","python3",str(r/"rebuild_cp2k_v2.py")])
text=run("ldd",container+["inspect","ldd",str(r/"bin/cp2k.psmp")])
assert str(r/"cp2k/cu-pinned-v2/libcp2k.so.2026.2") in text and "not found" not in text
s=(source/"cp_fm_cusolver.c").read_text()
macro=s[s.index("#define CUDA_CHECK(cmd)"):s.index("\n#if defined(__CUSOLVERMP_NCCL)",s.index("#define CUDA_CHECK(cmd)"))]
a=s.index('static void unregister_host_matrices(')
b=s.index('/*******************************************************************************\n * \\brief Driver routine to solve A*x',a)
(r/"pin-group.c").write_text('#define _POSIX_C_SOURCE 200809L\n#include <assert.h>\n#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <cuda_runtime.h>\n'+macro+'\n'+s[a:b]+(r/"pin-group-check.c").read_text())
cuda="/opt/devtools/nvidia/cuda-12.9.1"
run("group-check-build",container+["build","gcc","-O2","-std=c11","-Wall","-Wextra","-Werror","-I"+cuda+"/include",str(r/"pin-group.c"),"-L"+cuda+"/lib64","-Wl,-rpath,"+cuda+"/lib64","-lcudart","-o",str(r/"bin/pin-group")])
text=run("group-check",container+["inspect",str(r/"bin/pin-group")])
assert "HOST_GROUP_PASS" in text

rows={}
for variant in ("cu-base","cu-pinned"):
    work=out/(variant+"-lifecycle")
    work.mkdir()
    for path in (r/"validation-inputs").iterdir():
        if path.is_file(): shutil.copy2(path,work/path.name)
    text=run(variant+"-lifecycle",mpi+["python3",str(r/"rank-v2.py")],cwd=work,mode="lifecycle",variant=variant)
    assert "CP2K_CUSOLVER_LIFECYCLE_COMPLETE" in text
    records={}
    for path in work.glob("observables-g*.jsonl"):
        for line in path.read_text().splitlines():
            row=json.loads(line)
            key=f"{row['phase']}/{row['case']}/{row['group']}/{row['step']}"
            assert key not in records and len(row["forces"])==24
            assert all(math.isfinite(v) for v in [row["energy_ha"],*row["forces"]])
            records[key]=row
    assert len(records)==18
    for path in work.glob("*.out"):assert "diagonalization failed" not in path.read_text(errors="replace")
    rows[variant]=records
delta={}
for key,row in rows["cu-pinned"].items():
    base=rows["cu-base"][key]
    de=abs(row["energy_ha"]-base["energy_ha"])
    df=max(abs(a-b) for a,b in zip(row["forces"],base["forces"]))
    assert de<=1e-8 and df<=1e-7,(key,de,df)
    delta[key]=dict(energy_delta_ha=de,max_force_component_delta_ha_bohr=df)
(out/"lifecycle-audit.json").write_text(json.dumps(dict(accepted=True,comparisons=delta,observables=rows),indent=2)+"\n")

work=out/"regtest-cusolver"
shutil.copytree(old/"source/tests/QS/regtest-cusolver",work)
for path in (old/"source/tests/QS").glob("sample_*"):
    if path.is_dir():(out/path.name).symlink_to(path,target_is_directory=True)
regtests=[]
for filename,specs in tomllib.loads((work/"TEST_FILES.toml").read_text()).items():
    text=run(filename,mpi+["python3",str(r/"rank-v2.py"),"-i",filename],cwd=work)
    matches=[asdict(run_matcher(text,**spec)) for spec in specs]
    assert "PROGRAM ENDED" in text and all(m["status"]=="OK" for m in matches)
    regtests.append(dict(name=filename,matchers=matches,passed=True))
(out/"regtests.json").write_text(json.dumps(regtests,indent=2)+"\n")
(r/"results/functional-v2-completed.json").write_text(json.dumps(dict(accepted=True,job=os.environ["SLURM_JOB_ID"],source=q["cp2k_candidate"]),indent=2)+"\n")
