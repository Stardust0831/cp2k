#!/usr/bin/env bash
set -eo pipefail
validation_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
dependency_prefix=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["dependency_prefix"])' "$validation_root/request.json")
baseline_root=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["baseline_campaign"])' "$validation_root/request.json")
driver_ld=${LD_LIBRARY_PATH:-}
source "$dependency_prefix/share/sai/runtime-env.sh"
variant=${SAI_TRANSFER_VARIANT:-cu-base}
case "$variant" in
  cu-base|elpa-base|elpa-q) cp2k_lib="$validation_root/cp2k/cu-base" ;;
  cu-pinned) cp2k_lib="$validation_root/cp2k/cu-pinned-v2" ;;
  *) exit 2 ;;
esac
elpa_lib="$validation_root/elpa/elpa-base/lib"
[[ "$variant" != elpa-q ]] || elpa_lib="$validation_root/elpa/elpa-q/lib"
export CP2K_DATA_DIR="$baseline_root/source/data"
export LD_LIBRARY_PATH="$cp2k_lib:$elpa_lib:$baseline_root/deps/lib:$baseline_root/deps/lib64:$LD_LIBRARY_PATH${driver_ld:+:$driver_ld}"
if [[ "$1" == build ]]; then
  shift
  source /etc/profile.d/lmod.sh
  module purge
  module use /opt/modules/modulefiles/devtools
  module load cmake/3.31.6 openmpi/5.0.10-nvhpc26.3-gnu-cuda12-auto fftw/3.3.10 saiblas/2603-gnu-auto cuda/12.9.1 nvmplibs/26.7-tmp gcc/14.3.0 spglib/2.7.0
  export CC=/opt/devtools/gcc/14.3.0/bin/gcc CXX=/opt/devtools/gcc/14.3.0/bin/g++ FC=/opt/devtools/gcc/14.3.0/bin/gfortran
  export OMPI_CC="$CC" OMPI_CXX="$CXX" OMPI_FC="$FC"
  exec "$@"
fi
if [[ "$1" == inspect ]]; then
  shift
  exec "$@"
fi
if [[ "$1" == lifecycle ]]; then
  exec "$validation_root/bin/lifecycle"
fi
if [[ "$1" == q-trace ]]; then
  shift
  export LD_PRELOAD="$validation_root/bin/q-transfer-trace.so"
  exec "$validation_root/bin/elpa-check" "$@"
fi
if [[ "$1" == elpa-check ]]; then
  shift
  exec "$validation_root/bin/elpa-check" "$@"
fi
if [[ "$1" == pin-check ]]; then
  exec "$validation_root/bin/pin-check"
fi
[[ "$1" == run ]]
shift
exec "$validation_root/bin/cp2k.psmp" "$@"
