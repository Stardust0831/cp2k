"""Check CUDA copies spanning overlapping registered host pages on one V100."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

r=Path(__file__).resolve().parent
source=(r/"source/src/fm/cp_fm_cusolver.c").read_text()
macro=source[source.index("#define CUDA_CHECK(cmd)"):source.index("\n#if defined(__CUSOLVERMP_NCCL)",source.index("#define CUDA_CHECK(cmd)"))]
helper=re.search(r"static int register_host_matrix\(.*?\n\}",source,re.S)[0]
code='#define _POSIX_C_SOURCE 200809L\n#include <assert.h>\n#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <cuda_runtime.h>\n'+macro+'\n'+helper+'\n'+(r/"pin-check-body.c").read_text()
(r/"pin-overlap-check.c").write_text(code)
cuda="/opt/devtools/nvidia/cuda-12.9.1"
container=["python3",str(r/"container.py")]
with (r/"results/pin-overlap.log").open("w") as f:
    subprocess.run(container+["build","gcc","-O2","-std=c11","-Wall","-Wextra","-Werror",
        "-I"+cuda+"/include",str(r/"pin-overlap-check.c"),"-L"+cuda+"/lib64","-Wl,-rpath,"+cuda+"/lib64","-lcudart","-o",str(r/"bin/pin-overlap-check")],stdout=f,stderr=subprocess.STDOUT,check=True)
    subprocess.run(container+["inspect",str(r/"bin/pin-overlap-check")],stdout=f,stderr=subprocess.STDOUT,check=True)
text=(r/"results/pin-overlap.log").read_text()
assert "HOST_REGISTRATION_PASS" in text
(r/"results/pin-overlap.json").write_text(json.dumps(dict(accepted=True,job=os.environ["SLURM_JOB_ID"],source_sha256=hashlib.sha256(code.encode()).hexdigest(),summary=[s for s in text.splitlines() if s.startswith(("HOST_","OVERLAP_"))]),indent=2)+"\n")
