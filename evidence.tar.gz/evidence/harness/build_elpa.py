"""Identical release, compiler, GPU features and existing site patches for both builds."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
request = json.loads((root / "request.json").read_text())
mpi = Path("/opt/devtools/openmpi/openmpi-5.0.10-nvhpc263-gnu-cuda12-avx2")
blas = Path("/opt/devtools/saiblas/2603-gnu-avx2")
cuda = Path("/opt/devtools/nvidia/cuda-12.9.1")
hcoll = "/opt/devtools/nvidia/hpc_sdk/Linux_x86_64/26.3/comm_libs/12.9/hpcx/hpcx-2.25.1/hcoll"
flags = "-O2 -g -fno-omit-frame-pointer -fopenmp -fno-lto -march=x86-64-v3 -mtune=znver3 -mno-avx512f"
os.environ.update(OMPI_CC="/usr/bin/gcc", OMPI_CXX="/usr/bin/g++", OMPI_FC="/usr/bin/gfortran")
for compiler in ("gcc", "g++", "gfortran"):
    assert subprocess.check_output(["/usr/bin/"+compiler,"-dumpfullversion"],text=True).strip()=="13.3.0"

for variant in ("elpa-base", "elpa-q"):
    work = root / "elpa-build" / variant
    source, build, prefix = work / "source", work / "build", root / "elpa" / variant
    if not source.exists():
        source.mkdir(parents=True, exist_ok=False)
        build.mkdir()
        subprocess.run(["tar","--no-same-owner","--strip-components=1","-xzf",str(root / "elpa-2026.02.001.tar.gz"),"-C",str(source)],check=True)
        patches = [root / "elpa-patches" / n for n in request["elpa_patches"]]
        if variant == "elpa-q":
            patches.append(root / "elpa-requested-q.patch")
        for patch in patches:
            subprocess.run(["patch","--batch","--fuzz=0","-p1","-i",str(patch)],cwd=source,check=True)
    else:
        patches = [root / "elpa-patches" / n for n in request["elpa_patches"]]
        if variant == "elpa-q":
            patches.append(root / "elpa-requested-q.patch")
        for patch in patches:
            subprocess.run(["patch","--dry-run","--reverse","--batch","-p1","-i",str(patch)],cwd=source,check=True)
    options = [str(source / "configure"), "--prefix="+str(prefix), "--libdir="+str(prefix/"lib"),
        "--enable-openmp=yes", "--enable-static=no", "--enable-shared=yes", "--disable-c-tests",
        "--disable-cpp-tests", "--with-test-programs=no", "--disable-doxygen-doc",
        "--enable-avx-kernels=yes", "--enable-avx2-kernels=yes", "--enable-avx512-kernels=no",
        "--enable-nvidia-gpu-kernels=yes", "--with-cuda-path="+str(cuda),
        "--with-NVIDIA-GPU-compute-capability=sm_70,sm_75,sm_80,sm_86,sm_89",
        "--enable-nvidia-cub", "--with-cusolver", "--enable-cuda-aware-mpi",
        "--enable-nvidia-sm80-gpu", "--enable-nvidia-sm80-gpu-kernels",
        "CC="+str(mpi/"bin/mpicc"), "CXX="+str(mpi/"bin/mpicxx"), "FC="+str(mpi/"bin/mpifort"),
        "CPP=cpp -E", "CFLAGS="+flags, "CXXFLAGS="+flags, "FCFLAGS="+flags,
        f"LDFLAGS=-Wl,--allow-multiple-definition -Wl,--enable-new-dtags -L{blas}/lib -Wl,-rpath,{blas}/lib -Wl,-rpath,{hcoll}/lib -Wl,-rpath,{cuda}/lib64 -lstdc++",
        "LIBS=-lscalapack -lopenblas", "SCALAPACK_LDFLAGS=-L"+str(blas/"lib"), "SCALAPACK_FCFLAGS=-I"+str(blas/"include")]
    (work / "configure-command.json").write_text(json.dumps(options,indent=2)+"\n")
    for name,cmd in (("configure",options), ("make",["make","-j16","libelpa_openmp.la","elpa2_print_kernels_openmp"]),
                     ("install",["make","install","noinst_LTLIBRARIES=","noinst_PROGRAMS="])):
        print(variant, name, flush=True)
        logfile = work / (name+".log")
        if logfile.exists():
            logfile.rename(work / (name+"-before-hcoll-alias.log"))
        with logfile.open("w") as f:
            subprocess.run(cmd,cwd=build,stdout=f,stderr=subprocess.STDOUT,check=True)
    (prefix / "include/elpa").symlink_to("elpa_openmp-2026.02.001/elpa")
    receipt = dict(variant=variant, configure=options,
        library_sha256=hashlib.file_digest((prefix/"lib/libelpa_openmp.so").open("rb"),"sha256").hexdigest(),
        patches={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in patches})
    (work / "receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
