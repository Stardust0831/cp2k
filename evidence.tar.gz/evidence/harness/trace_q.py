"""Measure Q bytes separately from uninstrumented performance runs."""
import json
import os
from pathlib import Path
import re
import subprocess

r=Path(__file__).resolve().parent
out=r/"results/q-trace"
out.mkdir(exist_ok=False)
container=["python3",str(r/"container-trace.py")]
cuda="/opt/devtools/nvidia/cuda-12.9.1"
with (out/"build.log").open("w") as f:
    subprocess.run(container+["build","gcc","-O2","-Wall","-Wextra","-Werror","-fPIC","-shared","-I"+cuda+"/include",str(r/"q-transfer-trace.c"),"-ldl","-o",str(r/"bin/q-transfer-trace.so")],stdout=f,stderr=subprocess.STDOUT,check=True)
mpi=["mpirun","-np","4","--map-by","ppr:4:node:pe=4","--bind-to","core","--report-bindings"]
results=[]
for variant in ("elpa-base","elpa-q"):
    for nev,complex_case in ((16,0),(95,0),(95,1),(193,0)):
        name=f"{variant}-nev{nev}-complex{complex_case}"
        work=out/name
        work.mkdir()
        with (out/(name+".log")).open("w") as f:
            subprocess.run(mpi+["python3",str(r/"rank-trace.py"),str(nev),str(complex_case),"0"],cwd=work,env=dict(os.environ,SAI_TRANSFER_VARIANT=variant,SAI_TRANSFER_MODE="q-trace"),stdout=f,stderr=subprocess.STDOUT,check=True)
        text=(out/(name+".log")).read_text()
        assert text.count("ELPA_NUMERIC PASS")==2
        rows=[]
        for rank,full,upload,download,error in re.findall(r"Q_TRANSFER rank=(\d+) full=(\d+) upload=(\d+) download=(\d+) unregister=(\d+)",text):
            rank,full,upload,download,error=map(int,(rank,full,upload,download,error))
            nr=sum((i//64)%2==rank%2 for i in range(193))
            nc=sum((j//64)%2==rank//2 for j in range(193 if variant=="elpa-base" else nev))
            assert error==0 and upload==download==nr*nc*(16 if complex_case else 8),(name,rank,upload,nr,nc)
            rows.append(dict(rank=rank,full_bytes=full,upload_bytes=upload,download_bytes=download))
        assert len(rows)==8,(name,len(rows))
        results.append(dict(name=name,rows=rows,passed=True))
(out/"audit.json").write_text(json.dumps(dict(accepted=True,job=os.environ["SLURM_JOB_ID"],cases=results),indent=2)+"\n")
