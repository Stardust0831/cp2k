#define _GNU_SOURCE
#include <cuda_runtime.h>
#include <dlfcn.h>
#include <execinfo.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int solver_call(void) {
  void *frames[20];
  int n = backtrace(frames, 20);
  for (int i = 0; i < n; ++i) {
    Dl_info info;
    if (dladdr(frames[i], &info) && info.dli_sname &&
        (strstr(info.dli_sname, "cp_fm_diag_cusolver_sygvd") ||
         strstr(info.dli_sname, "cp_cfm_diag_cusolver_hegvd"))) return 1;
  }
  return 0;
}
cudaError_t cudaHostRegister(void *ptr, size_t size, unsigned int flags) {
  typedef cudaError_t (*fn)(void *, size_t, unsigned int);
  fn original = (fn)dlsym(RTLD_NEXT,"cudaHostRegister");
  cudaError_t error = original(ptr,size,flags);
  if (solver_call()) fprintf(stderr,"HOST_PIN rank=%s bytes=%zu error=%d\n",
                            getenv("OMPI_COMM_WORLD_RANK"),size,(int)error);
  return error;
}
cudaError_t cudaHostUnregister(void *ptr) {
  typedef cudaError_t (*fn)(void *);
  fn original = (fn)dlsym(RTLD_NEXT,"cudaHostUnregister");
  cudaError_t error = original(ptr);
  if (solver_call()) fprintf(stderr,"HOST_UNPIN rank=%s error=%d\n",
                            getenv("OMPI_COMM_WORLD_RANK"),(int)error);
  return error;
}
