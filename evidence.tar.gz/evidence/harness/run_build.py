"""Stage immutable sources, rebuild the changed code and keep build receipts."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
results = root / "results"
q = json.loads((root / "request.json").read_text())
digest = lambda p: hashlib.file_digest(Path(p).open("rb"),"sha256").hexdigest()
assert digest(q["image"]) == q["image_sha256"]
assert digest(root / "source-full-head.tar.gz") == q["source_archive_sha256"]
assert digest(root / "elpa-2026.02.001.tar.gz") == q["elpa_archive_sha256"]
for p,expected in q["files"].items():
    assert digest(root / p)==expected,p

def run(name,command):
    print("START",name,flush=True)
    (results/"build-stage.json").write_text(json.dumps(dict(stage=name,job=os.environ["SLURM_JOB_ID"])))
    start=time.monotonic()
    if (results/(name+".log")).exists():
        (results/(name+".log")).rename(results/(name+"-before-hcoll-alias.log"))
        (results/(name+"-receipt.json")).rename(results/(name+"-before-hcoll-alias-receipt.json"))
    with (results/(name+".log")).open("w") as f:
        code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT)
    (results/(name+"-receipt.json")).write_text(json.dumps(dict(command=command,exit_code=code,seconds=time.monotonic()-start,job=os.environ["SLURM_JOB_ID"]),indent=2)+"\n")
    print("END",name,code,round(time.monotonic()-start,2),flush=True)
    assert code==0,name

run("build-allocation",["scontrol","show","job","-o",os.environ["SLURM_JOB_ID"]])
container=["python3",str(root/"container.py"),"build","python3"]
if not (root/"source").exists():
    (root/"source").mkdir(exist_ok=False)
    run("source-extract",["tar","--no-same-owner","--strip-components=1","-xzf",str(root/"source-full-head.tar.gz"),"-C",str(root/"source")])
    run("source-patch",["patch","--batch","--fuzz=0","-p1","-d",str(root/"source"),"-i",str(root/"cusolver-host-pinning.patch")])
if not (results/"cp2k-build-provenance.json").exists():
    run("cp2k-rebuild",container+[str(root/"rebuild_cp2k.py")])
run("elpa-build",container+[str(root/"build_elpa.py")])
(results/"build-completed.json").write_text(json.dumps(dict(job=os.environ["SLURM_JOB_ID"],finished_at=datetime.now(timezone.utc).isoformat()),indent=2)+"\n")
print("BUILD_COMPLETE",flush=True)
