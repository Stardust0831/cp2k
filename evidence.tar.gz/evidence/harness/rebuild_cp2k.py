"""Recompile one object and relink both variants with identical frozen objects."""
import hashlib
import json
from pathlib import Path
import re
import shlex
import shutil
import subprocess

root = Path(__file__).resolve().parent
request = json.loads((root / "request.json").read_text())
old = Path(request["baseline_campaign"])
build = old / "build/src"
make = build / "CMakeFiles/cp2k.dir"
flags = dict(re.findall(r"^(C_DEFINES|C_INCLUDES|C_FLAGS) = (.*)$", (make / "flags.make").read_text(), re.M))
compile_args = ["/opt/devtools/gcc/14.3.0/bin/gcc"]
for name in ("C_DEFINES", "C_INCLUDES", "C_FLAGS"):
    compile_args += shlex.split(flags[name])
link_args = shlex.split((make / "link.txt").read_text())
assert link_args.count("@CMakeFiles/cp2k.dir/objects1.rsp") == 1
objects = shlex.split((make / "objects1.rsp").read_text())
target = "CMakeFiles/cp2k.dir/fm/cp_fm_cusolver.c.o"
assert objects.count(target) == 1
digest = lambda p: hashlib.file_digest(Path(p).open("rb"), "sha256").hexdigest()
provenance = dict(source_base=request["source_base"], candidate=request["cp2k_candidate"],
                  reused_objects={s:digest(build/s) for s in objects if s != target}, variants={})
(root / "bin").mkdir(exist_ok=True)
shutil.copy2(old / "build/bin/cp2k.psmp", root / "bin/cp2k.psmp")
for variant in ("cu-base", "cu-pinned"):
    output = root / "cp2k" / variant
    output.mkdir(parents=True, exist_ok=False)
    source = (old if variant == "cu-base" else root) / "source/src/fm/cp_fm_cusolver.c"
    obj = output / "cp_fm_cusolver.c.o"
    cmd = compile_args + ["-o", str(obj), "-c", str(source)]
    subprocess.run(cmd, cwd=build, check=True)
    rsp = output / "objects.rsp"
    rsp.write_text("\n".join(shlex.quote(str(obj) if s == target else str(build / s)) for s in objects) + "\n")
    link = link_args.copy()
    link[link.index("-o") + 1] = str(output / "libcp2k.so.2026.2")
    link[link.index("@CMakeFiles/cp2k.dir/objects1.rsp")] = "@" + str(rsp)
    link = ["-Wl,--dependency-file=" + str(output / "link.d") if s.startswith("-Wl,--dependency-file=") else s for s in link]
    subprocess.run(link, cwd=build, check=True)
    (output / "libcp2k.so").symlink_to("libcp2k.so.2026.2")
    provenance["variants"][variant] = dict(source=str(source), source_sha256=digest(source),
        compile_command=cmd, link_command=link, library_sha256=digest(output / "libcp2k.so.2026.2"))
provenance["executable_sha256"] = digest(root / "bin/cp2k.psmp")
(root / "results/cp2k-build-provenance.json").write_text(json.dumps(provenance,indent=2)+"\n")
