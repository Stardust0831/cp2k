"""Focused numerical acceptance followed by three paired ENERGY_FORCE repeats."""
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import tomllib

root = Path(__file__).resolve().parent
results = root / "results"
q = json.loads((root / "request.json").read_text())
old = Path(q["baseline_campaign"])
plan = json.loads((root / "benchmark-plan.json").read_text())
mpi = ["mpirun", "-np", "4", "--map-by", "ppr:4:node:pe=4", "--bind-to", "core", "--report-bindings"]
container = ["python3", str(root / "container.py")]
sys.path.insert(0, str(old / "source/tests"))
from matchers import run_matcher

def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

def run(name, command, cwd=root, timeout=600, variant="cu-base", mode="run"):
    receipt = dict(command=[str(v) for v in command], cwd=str(cwd), variant=variant, mode=mode,
                   job=os.environ["SLURM_JOB_ID"], started_at=datetime.now(timezone.utc).isoformat())
    (results / "current-stage.json").write_text(json.dumps(dict(stage=name, **receipt),indent=2)+"\n")
    print("START",name,flush=True)
    start=time.monotonic()
    env=dict(os.environ,SAI_TRANSFER_VARIANT=variant,SAI_TRANSFER_MODE=mode)
    if (results/(name+"-receipt.json")).exists():
        prior=json.loads((results/(name+"-receipt.json")).read_text())
        assert prior["exit_code"] != 0, "Do not repeat an already successful stage"
        (results/(name+".log")).rename(results/(name+"-missing-relative-fixture.log"))
        (results/(name+"-receipt.json")).rename(results/(name+"-missing-relative-fixture-receipt.json"))
    with (results/(name+".log")).open("w") as log:
        process=subprocess.Popen(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            receipt["exit_code"]=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            receipt.update(exit_code=124,timed_out=True)
            os.killpg(process.pid,signal.SIGTERM)
            try:
                process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                process.wait(timeout=20)
    receipt.update(seconds=time.monotonic()-start,finished_at=datetime.now(timezone.utc).isoformat())
    (results/(name+"-receipt.json")).write_text(json.dumps(receipt,indent=2)+"\n")
    print("END",name,receipt["exit_code"],round(receipt["seconds"],3),flush=True)
    assert receipt["exit_code"]==0,(name,receipt)
    return (results/(name+".log")).read_text(errors="replace")

assert (results/"build-completed.json").is_file()
assert json.loads((results/"lifecycle-audit.json").read_text())["accepted"]
assert len(json.loads((results/"elpa-checks.json").read_text()))==24
assert "HOST_REGISTRATION_PASS" in (results/"pin-check.log").read_text()
run("benchmark-allocation",["scontrol","show","job","-o",os.environ["SLURM_JOB_ID"]])
# Preserve upstream relative coordinate/data references in the copied suites.
for sample in (old/"source/tests/QS").iterdir():
    if sample.is_dir() and sample.name.startswith("sample_"):
        target=results/sample.name
        if not target.exists(): target.symlink_to(sample,target_is_directory=True)
regtests=json.loads((results/"regtests.json").read_text()) if (results/"regtests.json").exists() else []
completed_names={row["name"] for row in regtests if row["passed"]}
for variant,dirs in (("cu-base",["regtest-cusolver"]),("cu-pinned",["regtest-cusolver"]),
                     ("elpa-base",["regtest-elpa","regtest-elpa-2"]),("elpa-q",["regtest-elpa","regtest-elpa-2"])):
    for directory in dirs:
        source=old/"source/tests/QS"/directory
        specs=tomllib.loads((source/"TEST_FILES.toml").read_text())
        # Several upstream tests share files within the directory.
        work=results/(variant+"-"+directory)
        shutil.copytree(source,work,dirs_exist_ok=True)
        for filename,matchers in specs.items():
            name=variant+"-"+directory+"-"+filename.removesuffix(".inp")
            if name in completed_names: continue
            output=run(name,mpi+["python3",str(root/"rank.py"),"-i",filename],cwd=work,variant=variant,timeout=300)
            (work/(filename+".out")).write_text(output)
            matches=[asdict(run_matcher(output,**spec)) for spec in matchers]
            row=dict(name=name,matchers=matches,passed="PROGRAM ENDED" in output and all(m["status"]=="OK" for m in matches))
            regtests.append(row)
            (results/"regtests.json").write_text(json.dumps(regtests,indent=2)+"\n")
            assert row["passed"],row

(results/"functional-completed.json").write_text(json.dumps(dict(job=os.environ["SLURM_JOB_ID"],finished_at=datetime.now(timezone.utc).isoformat()),indent=2)+"\n")
for case in plan:
    name=case["name"]
    work=results/name
    shutil.copytree(root/case["input"],work)
    assert not any(".wfn" in p.name.lower() for p in work.iterdir())
    text=run(name,mpi+["python3",str(root/"rank.py"),"-i","input.inp"],cwd=work,variant=case["variant"],timeout=case["timeout"])
    (work/"cp2k.out").write_text(text)
    subprocess.run(["python3",str(root/"audit_benchmark.py"),"--partial"],check=True)
subprocess.run(["python3",str(root/"audit_benchmark.py")],check=True)
(results/"benchmark-completed.json").write_text(json.dumps(dict(job=os.environ["SLURM_JOB_ID"],finished_at=datetime.now(timezone.utc).isoformat()),indent=2)+"\n")
print("TRANSFER_E2E_COMPLETE",flush=True)
