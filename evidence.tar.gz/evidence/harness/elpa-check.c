/* Requested eigenvectors on an uneven 2x2 block-cyclic grid, including empty
 * local output columns. Analytic spectrum plus residual and orthogonality. */
#include <complex.h>
#include <math.h>
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <elpa/elpa.h>

static int rank_id;
static void check(int error, const char *where) {
    if (error != ELPA_OK) {
        fprintf(stderr, "rank %d %s: %d\n", rank_id, where, error);
        MPI_Abort(MPI_COMM_WORLD, 1);
    }
}
static void set(elpa_t e, const char *key, int value) {
    int error;
    elpa_set(e, key, value, &error);
    check(error, key);
}
static int global_index(int local, int process, int nb) {
    return (local / nb * 2 + process) * nb + local % nb;
}
static int local_count(int n, int process, int nb) {
    int count = 0;
    for (int i = 0; i < n; ++i) count += (i / nb) % 2 == process;
    return count;
}
int main(int argc, char **argv) {
    int provided, ranks, error;
    MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &provided);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank_id);
    MPI_Comm_size(MPI_COMM_WORLD, &ranks);
    if (argc != 4 || ranks != 4 || provided < MPI_THREAD_FUNNELED)
        MPI_Abort(MPI_COMM_WORLD, 2);
    const int n = 193, nb = 64, nev = atoi(argv[1]);
    const int is_complex = atoi(argv[2]), nonblocking = atoi(argv[3]);
    const int prow = rank_id % 2, pcol = rank_id / 2;
    const int nr = local_count(n, prow, nb), nc = local_count(n, pcol, nb);
    if (nev < 1 || nev > n) MPI_Abort(MPI_COMM_WORLD, 3);
    check(elpa_init(20221109), "init");
    elpa_t e = elpa_allocate(&error);
    check(error, "allocate");
    set(e, "na", n); set(e, "nev", nev); set(e, "nblk", nb);
    set(e, "local_nrows", nr); set(e, "local_ncols", nc);
    set(e, "mpi_comm_parent", (int)MPI_Comm_c2f(MPI_COMM_WORLD));
    set(e, "process_row", prow); set(e, "process_col", pcol);
    set(e, "omp_threads", 4);
    check(elpa_setup(e), "setup");
    set(e, "solver", ELPA_SOLVER_2STAGE);
    set(e, "nbc_row_elpa2_band_to_full", nonblocking);
    set(e, "nbc_col_elpa2_tridi_to_band", nonblocking);
    set(e, "nvidia-gpu", 1);
    set(e, is_complex ? "complex_kernel" : "real_kernel", is_complex ?
        ELPA_2STAGE_COMPLEX_NVIDIA_GPU : ELPA_2STAGE_REAL_NVIDIA_GPU);
    set(e, "use_gpu_id", 0);
    check(elpa_setup_gpu(e), "setup_gpu");
    const double complex gamma = is_complex ? -0.3 + 0.4 * I : -0.5;
    double *eval = calloc(n, sizeof(double));
    for (int repeat = 0; repeat < 2; ++repeat) {
        double complex *qall = calloc(n * nev, sizeof(double complex));
        if (is_complex) {
            double complex *a = calloc(nr * nc, sizeof(double complex));
            double complex *q = calloc(nr * nc, sizeof(double complex));
            for (int j = 0; j < nc; ++j) for (int i = 0; i < nr; ++i) {
                int gi = global_index(i, prow, nb), gj = global_index(j, pcol, nb);
                a[i+j*nr] = gi == gj ? 2.0 : (gi == gj-1 ? gamma : (gi == gj+1 ? conj(gamma) : 0));
            }
            elpa_eigenvectors_double_complex(e, a, eval, q, &error);
            check(error, "complex eigenvectors");
            for (int j = 0; j < nc; ++j) for (int i = 0; i < nr; ++i) {
                int gi = global_index(i, prow, nb), gj = global_index(j, pcol, nb);
                if (gj < nev) qall[gi+gj*n] = q[i+j*nr];
            }
            free(a); free(q);
        } else {
            double *a = calloc(nr * nc, sizeof(double)), *q = calloc(nr * nc, sizeof(double));
            for (int j = 0; j < nc; ++j) for (int i = 0; i < nr; ++i) {
                int gi = global_index(i, prow, nb), gj = global_index(j, pcol, nb);
                a[i+j*nr] = gi == gj ? 2.0 : (abs(gi-gj) == 1 ? -0.5 : 0);
            }
            elpa_eigenvectors_double(e, a, eval, q, &error);
            check(error, "real eigenvectors");
            for (int j = 0; j < nc; ++j) for (int i = 0; i < nr; ++i) {
                int gi = global_index(i, prow, nb), gj = global_index(j, pcol, nb);
                if (gj < nev) qall[gi+gj*n] = q[i+j*nr];
            }
            free(a); free(q);
        }
        MPI_Allreduce(MPI_IN_PLACE, qall, n * nev, MPI_C_DOUBLE_COMPLEX, MPI_SUM, MPI_COMM_WORLD);
        double spectrum = 0, residual = 0, orthogonality = 0;
        for (int j = 0; j < nev; ++j) {
            spectrum = fmax(spectrum, fabs(eval[j] - (2.0-cos((j+1)*acos(-1.0)/(n+1)))));
            for (int i = 0; i < n; ++i) {
                double complex r = (2.0-eval[j])*qall[i+j*n];
                if (i) r += conj(gamma)*qall[i-1+j*n];
                if (i+1 < n) r += gamma*qall[i+1+j*n];
                residual = fmax(residual, cabs(r));
            }
            for (int i = 0; i < nev; ++i) {
                double complex dot = 0;
                for (int k = 0; k < n; ++k) dot += conj(qall[k+i*n])*qall[k+j*n];
                orthogonality = fmax(orthogonality, cabs(dot - (i == j ? 1.0 : 0.0)));
            }
        }
        int ok = isfinite(spectrum) && isfinite(residual) && isfinite(orthogonality) &&
            spectrum < 1e-10 && residual < 1e-10 && orthogonality < 1e-10;
        for (int i = 0; i < nev; ++i) ok &= isfinite(eval[i]);
        for (int i = 0; i < n * nev; ++i) ok &= isfinite(creal(qall[i])) && isfinite(cimag(qall[i]));
        if (!rank_id) printf("ELPA_NUMERIC %s n=%d nev=%d grid=2x2 nb=%d complex=%d nonblocking=%d repeat=%d spectrum=%.3e residual=%.3e orthogonality=%.3e\n",
            ok ? "PASS" : "FAIL", n, nev, nb, is_complex, nonblocking, repeat, spectrum, residual, orthogonality);
        if (!ok) MPI_Abort(MPI_COMM_WORLD, 4);
        free(qall);
    }
    free(eval);
    elpa_deallocate(e, &error); check(error, "deallocate");
    elpa_uninit(&error); check(error, "uninit");
    MPI_Finalize();
    return 0;
}
