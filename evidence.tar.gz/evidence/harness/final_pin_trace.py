"""Validate final formatted source and successful large-matrix registrations."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

r=Path(__file__).resolve().parent
q=json.loads((r/"request-final.json").read_text())
out=r/"results/final-pin-trace"
out.mkdir(exist_ok=False)
os.environ.update(SAI_TRANSFER_VARIANT="cu-pinned",SAI_TRANSFER_MODE="run")
container=["python3",str(r/"container-final.py")]
old=Path(q["baseline_campaign"])
source=r/"source-final/src/fm"
source.mkdir(parents=True)
shutil.copy2(r/"cp_fm_cusolver-final.c",source/"cp_fm_cusolver.c")
(source.parent/"offload").symlink_to(old/"source/src/offload",target_is_directory=True)
def run(name,args,cwd=r):
    start=time.monotonic()
    with (out/(name+".log")).open("w") as f:p=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
    (out/(name+"-receipt.json")).write_text(json.dumps(dict(exit_code=p.returncode,command=args,seconds=time.monotonic()-start,job=os.environ["SLURM_JOB_ID"]),indent=2)+"\n")
    assert p.returncode==0,name
    return (out/(name+".log")).read_text(errors="replace")
run("build",container+["build","python3",str(r/"rebuild_cp2k_final.py")])
cuda="/opt/devtools/nvidia/cuda-12.9.1"
run("tracer-build",container+["build","gcc","-O2","-Wall","-Wextra","-Werror","-fPIC","-shared","-I"+cuda+"/include",str(r/"pin-trace.c"),"-ldl","-o",str(r/"bin/pin-trace.so")])
text=run("ldd",container+["inspect","ldd",str(r/"bin/cp2k.psmp")])
assert str(r/"cp2k/cu-pinned-final/libcp2k.so.2026.2") in text and "not found" not in text
work=out/"ag-cusolver"
shutil.copytree(r/"inputs/ag-cusolver",work)
mpi=["mpirun","-np","4","--map-by","ppr:4:node:pe=4","--bind-to","core","--report-bindings"]
text=run("ag-cusolver",mpi+["python3",str(r/"rank-final.py"),"-i","input.inp"],cwd=work)
assert "PROGRAM ENDED" in text and "SCF run converged in    10 steps" in text
registrations=[tuple(map(int,t)) for t in re.findall(r"HOST_PIN rank=(\d+) bytes=(\d+) error=(\d+)",text)]
unregistrations=[tuple(map(int,t)) for t in re.findall(r"HOST_UNPIN rank=(\d+) error=(\d+)",text)]
assert len(registrations)==120 and all(t[2]==0 for t in registrations),registrations
assert len(unregistrations)==120 and all(t[1]==0 for t in unregistrations),unregistrations
assert all(sum(t[0]==rank for t in registrations)==30 for rank in range(4))
assert sum(t[1] for t in registrations)==10*(2*12500*12500+12500*3250)*8
number=r"[-+]?\d+(?:\.\d*)?(?:[EeDd][-+]?\d+)?"
energy=float(re.findall(r"ENERGY\| Total FORCE_EVAL[^\n]*?("+number+r")\s*$",text,re.M)[0])
rows=re.findall(r"^\s*FORCES\|\s+(\d+)\s+("+number+r")\s+("+number+r")\s+("+number+r")\s+"+number+r"\s*$",text,re.M)
assert [int(t[0]) for t in rows]==list(range(1,501))
forces=[float(x) for row in rows for x in row[1:]]
base=json.loads((r/"results/benchmarks/audit-ag-cusolver.json").read_text())["cases"]["ag-cu-base-r1"]
de=abs(energy-base["energy_ha"])
df=max(abs(a-b) for a,b in zip(forces,base["forces"]))
assert de<=1e-6 and df<=1e-5,(de,df)
(out/"audit.json").write_text(json.dumps(dict(accepted=True,source=q["cp2k_candidate"],job=os.environ["SLURM_JOB_ID"],
    successful_registrations=len(registrations),successful_unregistrations=len(unregistrations),registered_bytes=sum(t[1] for t in registrations),
    energy_delta_ha=de,max_force_component_delta_ha_bohr=df,scf_steps=10,performance_comparison=False),indent=2)+"\n")
